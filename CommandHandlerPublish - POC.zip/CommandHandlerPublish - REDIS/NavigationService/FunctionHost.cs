using Asset.Events.Serialization;
using MassTransit;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.SignalRService;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace NavigationService.Functions
{
    public class FunctionHost : ServerlessHub
    {
        private readonly ILoggerFactory _loggerFactory;
        private readonly IPublishEndpoint _publishEndpoint;

        public FunctionHost(ILoggerFactory loggerFactory, IPublishEndpoint publishEndpoint)
        {
            _loggerFactory = loggerFactory;
            _publishEndpoint = publishEndpoint;
        }

        [FunctionName(nameof(GetAssets))]
        public async Task GetAssets([SignalRTrigger] InvocationContext invocationContext, string message)
        {
            var getAssetsEvent = JsonConvert.DeserializeObject<GetAssets>(message);
            getAssetsEvent.ConnectionId = invocationContext.ConnectionId;
            await _publishEndpoint.Publish<GetAssets>(getAssetsEvent);
        }
    }
}
