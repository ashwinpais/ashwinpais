﻿using Asset.Events.Serialization;
using EventStore.Abstractions;
using Newtonsoft.Json;

namespace Asset.Domain.Aggregates
{
    public class AssetState : IState
    {
        [JsonProperty("id")]
        public string AssetId { get; set; }
        [JsonProperty("assetName")]
        public string AssetName { get; set; }
        [JsonProperty("presentValue")]
        public string PresentValue { get; set; }
        [JsonProperty("description")]
        public string Description { get; set; }
        [JsonProperty("isActive")]
        public bool IsActive { get; set; }

        public AssetState()
        {

        }

        public void When(AssetConstructed e)
        {
            IsActive = true;
            AssetName = e.AssetName;
            AssetId = e.AssetId;
            PresentValue = e.PresentValue;
            Description = e.Description;
        }

        public void When(AssetDestructed e)
        {
            AssetId = e.AssetId;
            IsActive = false;
        }

        public void When(AssetAssigned e)
        {
            AssetId = e.AssetId;
            AssetName = e.AssetName;
            PresentValue = e.PresentValue;
            Description = e.Description;
        }

        public void Mutate(IEvent e)
        {
            // .NET magic to call one of the 'When' handlers with 
            // matching signature 
            ((dynamic)this).When((dynamic)e);
        }
    }
}
