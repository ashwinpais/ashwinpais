﻿using EventStore.Abstractions;
using System;
using System.Collections.Generic;

namespace Asset.Domain.Aggregates
{
    public class EntityModel<T> where T : IState
    {
        public DateTimeOffset EventTime { get; set; }

        public T entityState;

        public string AggregateId;

        public EntityModel()
        {
        }

        public void Apply(IEnumerable<IEvent> events, DateTimeOffset eventTime)
        {
            ReplayEvents(events);
            EventTime = eventTime;
        }

        public void ReplayEvents(IEnumerable<IEvent> events)
        {
            foreach (var @event in events)
            {
                entityState.Mutate(@event);
            }
        }
    }
}


