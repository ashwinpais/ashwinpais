﻿namespace Asset.Domain.Aggregates
{
    public interface IEntityModel
    {
    }
}


