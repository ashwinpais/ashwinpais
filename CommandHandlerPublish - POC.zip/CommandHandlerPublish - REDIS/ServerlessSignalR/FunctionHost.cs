﻿using Asset.Events.Serialization;
using MassTransit;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.SignalRService;
using System.Threading.Tasks;

namespace ServelessSignalR.Functions
{
    public class FunctionHost : ServerlessHub, IConsumer<ResponseMessage>
    {
        private const string NewMessageTarget = "newMessage";


        [FunctionName("negotiate")]
        public SignalRConnectionInfo Negotiate([HttpTrigger(AuthorizationLevel.Anonymous)] HttpRequest req)
        {
            return Negotiate(req.Headers["x-ms-signalr-user-id"], GetClaims(req.Headers["Authorization"]));
        }

        [FunctionName(nameof(OnConnected))]
        public void OnConnected([SignalRTrigger] InvocationContext invocationContext)
        {
        }

        [FunctionName(nameof(OnDisconnected))]
        public void OnDisconnected([SignalRTrigger] InvocationContext invocationContext)
        {
        }

        async Task IConsumer<ResponseMessage>.Consume(ConsumeContext<ResponseMessage> context)
        {
            var message = context.Message;
            string connectionId = message.ConnectionId;
            await Clients.User(message.UserId).SendAsync(NewMessageTarget, new NewMessage(context.Message));
        }
    }
}
