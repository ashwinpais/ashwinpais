﻿using Asset.Events.Serialization;

namespace ServelessSignalR.Functions
{
    public class NewMessage
    {
        public string ConnectionId { get; }
        public string Sender { get; }
        public string Text { get; }

        public NewMessage(ResponseMessage message)
        {
            Sender = string.IsNullOrEmpty(message.UserId) ? string.Empty : message.UserId;
            ConnectionId = message.ConnectionId;
            Text = message.MessageText;
        }
    }
}
