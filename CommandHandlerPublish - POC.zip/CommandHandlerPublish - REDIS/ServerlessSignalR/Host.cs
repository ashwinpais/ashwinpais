using MassTransit.WebJobs.ServiceBusIntegration;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ServelessSignalR.Functions
{
    public class Host
    {

        private readonly IMessageReceiver _receiver;

        public Host(IMessageReceiver receiver)
        {
            _receiver = receiver;
        }

        [FunctionName("sendresponsetosignalr")]
        public Task SendResponseToSignalR([ServiceBusTrigger("signalr-queue")] Message message, CancellationToken cancellationToken)
        {
            byte[] messageBodyBytes = message.Body;
            string messageBodyString = Encoding.UTF8.GetString(messageBodyBytes);
            return _receiver.HandleConsumer<FunctionHost>("sendresponsetosignalr", message, cancellationToken);
        }
    }
}
