using Microsoft.Azure.Functions.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(ServelessSignalR.Functions.Startup))]
namespace ServelessSignalR.Functions
{
    using Asset.Events.Serialization;
    using Common;
    using MassTransit;
    using Microsoft.Azure.Functions.Extensions.DependencyInjection;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    public class Startup : FunctionsStartup
    {
        public IConfiguration Configuration { get; }

        public Startup() =>
            Configuration = new ConfigurationBuilder()
                .AddEnvironmentVariables()
                .Build();

        public override void Configure(IFunctionsHostBuilder functionsHostBuilder)
        {
            IServiceCollection services = functionsHostBuilder.Services;
            var connection = Configuration.GetSection("AzureWebJobsServiceBus").Value.ToString();

            var loggerFactory = (ILoggerFactory)new LoggerFactory();

            services.AddSingleton<ILoggerFactory>(loggerFactory);

            services.AddScoped<FunctionHost>();

            services.AddMassTransitForAzureFunctions(config =>
            {
                _ = config.AddConsumer<FunctionHost>();
            }, busconfig =>
            {
                busconfig.AutoStart = true;

                busconfig.ReceiveEndpoint("signalr-queue", e =>
                {
                    e.Consumer<FunctionHost>();
                });

                busconfig.ConfigureSerialization(ResponseMessage.Descriptor);
            });
        }
    }
}
