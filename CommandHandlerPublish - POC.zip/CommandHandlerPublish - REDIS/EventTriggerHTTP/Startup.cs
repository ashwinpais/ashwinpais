﻿using MassTransit;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(EventTriggerHTTP.Startup))]
namespace EventTriggerHTTP
{
    public class Startup :
        FunctionsStartup
    {
        public IConfiguration Configuration { get; } = new ConfigurationBuilder()
            .AddEnvironmentVariables()
            .AddUserSecrets<Startup>()
            .Build();

        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddMassTransitForAzureFunctions(config =>
            {
            }, busconfig =>
            {
                busconfig.ConfigureHost(builder.Services.BuildServiceProvider());
            });
        }
    }
}
