﻿using Asset.Events.Serialization;
using Common;
using MassTransit;
using System;

namespace EventTriggerHTTP
{
    static public class DependencyInjectionExtensions
    {
        public static void ConfigureHost<T>(this T configurator, IServiceProvider provider)
            where T : IBusFactoryConfigurator, IReceiveConfigurator<IReceiveEndpointConfigurator>
        {
            configurator.AutoStart = true;

            configurator.Message<ConstructAsset>(configTopology =>
            {
                configTopology.SetEntityName("commandtopic");
            });

            configurator.Message<AssignAsset>(configTopology =>
            {
                configTopology.SetEntityName("commandtopic");
            });

            configurator.Message<DestructAsset>(configTopology =>
            {
                configTopology.SetEntityName("commandtopic");
            });

            _ = provider;
            configurator.ConfigureSerialization(ConstructAsset.Descriptor,
                                                AssignAsset.Descriptor,
                                                DestructAsset.Descriptor);
        }
    }
}
