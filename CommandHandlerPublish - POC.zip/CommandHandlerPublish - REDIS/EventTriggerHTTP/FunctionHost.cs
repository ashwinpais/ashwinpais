using Asset.Domain.Aggregates;
using EventStore.App;
using MassTransit;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading;

namespace EventTriggerHTTP
{
    public class FunctionHost
    {
        private readonly IPublishEndpoint _publishEndpoint;

        public FunctionHost(IPublishEndpoint publishEndpoint)
        {
            _publishEndpoint = publishEndpoint;
        }

        //[FunctionName("CreateAssetFunction")]
        //public async Task<IActionResult> CreateAsset([HttpTrigger(AuthorizationLevel.Function, "post", Route = "createAsset")] HttpRequest req,
        //    ILogger log, CancellationToken cancellationToken)
        //{
        //    string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //    var createAssetEvent = JsonConvert.DeserializeObject<AssetCreated>(requestBody);
        //    await _publishEndpoint.Publish<AssetCreated>(createAssetEvent);
        //    return new OkResult();
        //}

        //[FunctionName("EditAssetFunction")]
        //public async Task<IActionResult> EditAsset([HttpTrigger(AuthorizationLevel.Function, "post", Route = "editAsset")] HttpRequest req,
        //   ILogger log, CancellationToken cancellationToken)
        //{
        //    string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //    var editAssetEvent = JsonConvert.DeserializeObject<AssetEdited>(requestBody);
        //    await _publishEndpoint.Publish<AssetEdited>(editAssetEvent);
        //    return new OkResult();
        //}

        //[FunctionName("DeleteAssetFunction")]
        //public async Task<IActionResult> DeleteAsset([HttpTrigger(AuthorizationLevel.Function, "post", Route = "deleteAsset")] HttpRequest req,
        //   ILogger log, CancellationToken cancellationToken)
        //{
        //    string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //    var deleteAssetEvent = JsonConvert.DeserializeObject<AssetDeleted>(requestBody);
        //    await _publishEndpoint.Publish<AssetDeleted>(deleteAssetEvent);
        //    return new OkResult();
        //}

        [FunctionName("GetAssets")]
        public IActionResult GetAssets([HttpTrigger(AuthorizationLevel.Function, "get", Route = "getAsset")] HttpRequest req,
           ILogger log, CancellationToken cancellationToken)
        {
            CosmosClient _client;
            string _databaseId;
            string _containerId;
            _client = new CosmosClient("https://gdwm.documents.azure.com:443/", "n1U1SO2CpiIhfLlXT6V0AoJ3muu4Fmhp3SkVLS3NtKzbcOAyLjhQ3jnBFL9I5S1aJqcEfmtKn3GaNkLoMWJsng==");
            _databaseId = "ntdemodb";
            _containerId = "assetcache";

            Container container = _client.GetContainer(_databaseId, _containerId);

            var sqlQueryText = "SELECT * FROM assetcache e"
                + " ORDER BY e.eventTime";

            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);

            FeedIterator<StateWrapper> feedIterator = container.GetItemQueryIterator<StateWrapper>(queryDefinition);

            List<AssetState> assetStates = new List<AssetState>();

            while (feedIterator.HasMoreResults)
            {
                FeedResponse<StateWrapper> response = feedIterator.ReadNextAsync().Result;
                foreach (var eventWrapper in response)
                {
                    var stateData = eventWrapper.StateData;

                    var assetState = (JsonConvert.DeserializeObject<AssetState>(stateData, new JsonSerializerSettings()
                    {
                        TypeNameHandling = TypeNameHandling.All
                    }));

                    assetStates.Add(assetState);
                }
            }

            return new OkObjectResult(new { data = assetStates });
        }
    }
}
