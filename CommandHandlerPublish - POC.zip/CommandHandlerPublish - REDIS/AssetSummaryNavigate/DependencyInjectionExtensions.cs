﻿using Asset.Events.Serialization;
using Common;
using MassTransit;
using System;

namespace HydrationService
{
    static public class DependencyInjectionExtensions
    {
        public static void ConfigureHost<T>(this T configurator, IServiceProvider provider)
            where T : IBusFactoryConfigurator, IReceiveConfigurator<IReceiveEndpointConfigurator>
        {
            configurator.AutoStart = true;

            _ = provider;

            configurator.Message<ResponseMessage>(configTopology =>
            {
                configTopology.SetEntityName("signalr-topic");
            });

            configurator.Message<HydrateRequest>(configTopology =>
            {
                configTopology.SetEntityName("hydrationtopic");
            });

            configurator.ConfigureSerialization(ResponseMessage.Descriptor,
                                                HydrateRequest.Descriptor);
        }
    }
}
