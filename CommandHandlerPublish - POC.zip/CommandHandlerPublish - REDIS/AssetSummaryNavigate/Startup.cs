﻿using EventStore.Abstractions;
using EventStore.App;
using EventStore.App.CosmosDB;
using MassTransit;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(HydrationService.Startup))]
namespace HydrationService
{
    public class Startup : FunctionsStartup
    {
        public IConfiguration Configuration { get; } = new ConfigurationBuilder()
            .AddEnvironmentVariables()
            .AddUserSecrets<Startup>()
            .Build();

        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddMassTransitForAzureFunctions(config =>
            {
                _ = config.AddConsumer<AssetSummaryNavigateConsumer>();
            }, busconfig =>
            {
                busconfig.ConfigureHost(builder.Services.BuildServiceProvider());
            });

            builder.Services.AddTransient<IEventStream, EventStream>();

            string Get(string key) => Configuration.GetConnectionStringOrSetting(key);
            string endpointUrl = Get("ENDPOINT_URL");
            string authorizationKey = Get("AUTHORIZATION_KEY");
            string databaseId = Get("DATABASE_ID");

            builder.Services.AddTransient<IEventStore>(provider =>
                                                       new CosmosDBEventStore(endpointUrl,
                                                        authorizationKey, databaseId));
        }
    }
}

