﻿using Asset.Events.Serialization;
using EventStore.Abstractions;
using MassTransit;
using System.Threading.Tasks;

namespace HydrationService
{
    public class AssetSummaryNavigateConsumer : IConsumer<GetAssets>
    {
        private readonly IEventStore _eventStore;

        public AssetSummaryNavigateConsumer(IEventStore eventStore)
        {
            _eventStore = eventStore;
        }

        Task IConsumer<GetAssets>.Consume(ConsumeContext<GetAssets> context)
        {
            var message = context.Message;

            var assets = _eventStore.GetStates(message.UserId).ConfigureAwait(false).GetAwaiter().GetResult(); ;

            var emptyState = "[]";
            if (string.Compare(assets, emptyState) != 0)
            {
                context.Publish(new ResponseMessage()
                {
                    UserId = message.UserId,
                    ConnectionId = message.ConnectionId,
                    MessageText = assets
                });
            }
            else
            {
                context.Publish(new HydrateRequest()
                {
                    ConnectionId = message.ConnectionId,
                    UserId = message.UserId,
                    AggregateType = "assetevents",
                    ClassToInstantiate = "Asset.Domain.Aggregates.AssetState, Asset.Aggregates"
                });
            }

            return Task.CompletedTask;
        }
    }
}
