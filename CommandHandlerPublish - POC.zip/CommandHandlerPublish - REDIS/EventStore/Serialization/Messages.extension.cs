﻿using System;
using Common.Serialization;
using MassTransit;

namespace EventStore.Store.Serialization
{
	public partial class EventWriteRequest : ICorrelated
	{
		Guid CorrelatedBy<Guid>.CorrelationId => this.CorrelationId();
	}

	public partial class EventWriteResponse : ICorrelated
	{
		Guid CorrelatedBy<Guid>.CorrelationId => this.CorrelationId();
	}

	public partial class Event : ICorrelated
	{
		Guid CorrelatedBy<Guid>.CorrelationId => this.CorrelationId();
	}
}