﻿namespace EventStore.Abstractions
{
    public interface IState
    {
        public bool IsActive { get; set; }

        public void Mutate(IEvent e);
    }
}
