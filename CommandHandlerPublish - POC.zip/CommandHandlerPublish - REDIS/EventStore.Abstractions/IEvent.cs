﻿using Google.Protobuf;

namespace EventStore.Abstractions
{
    public interface IEvent : IMessage
    {
    }
}
