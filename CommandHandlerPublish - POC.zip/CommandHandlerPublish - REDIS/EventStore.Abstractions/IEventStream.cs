﻿using System;
using System.Collections.Generic;

namespace EventStore.Abstractions
{
    public interface IEventStream
    {
        public string AggregateId { get; }

        public IEnumerable<IEvent> Events { get; }

        public DateTimeOffset EventTime { get; }
    }
}
