﻿using EventStore.Store.Serialization;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EventStore.Abstractions
{
    public interface IEventStore
    {
        Task<List<EventDetails>> Get(string aggregateType, string userId);

        Task<IEventStream> Get(string aggregateId, string aggregateType, string userId);

        Task<IEventStream> Get(string aggregateId, string aggregateType, string userId, DateTimeOffset fromEventTime);

        Task<IEventStream> Get(string aggregateId, string aggregateType, DateTimeOffset fromEventTime);

        Task<bool> SaveState(string aggregateId, string userId, IState state,
                             DateTimeOffset eventTime, bool isDelete);

        Task<bool> Save(string aggregateId,
                        string aggregateType,
                        string userId,
                        string eventName,
                        string eventData);

        Task<string> GetStates(string userId);

        Task<List<IEventStream>> GetEventStreams(string aggregateType);
    }
}
