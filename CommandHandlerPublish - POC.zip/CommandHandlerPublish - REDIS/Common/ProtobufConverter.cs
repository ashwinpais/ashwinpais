﻿using Google.Protobuf;
using Google.Protobuf.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;

namespace Common
{
    public class ProtobufConverter : Newtonsoft.Json.JsonConverter
    {
        private readonly JsonParser _parser;
        private readonly JsonFormatter _formatter;

        public static ProtobufConverter Create(int recursionLimit = 3,
            params MessageDescriptor[] descriptors)
        {
            var registry = TypeRegistry.FromMessages(descriptors);
            var parserSettings = new JsonParser.Settings(recursionLimit, registry);
            var parser = new JsonParser(parserSettings);
            var formatterSettings = new JsonFormatter.Settings(false, registry);
            var formatter = new JsonFormatter(formatterSettings);
            return new ProtobufConverter(parser, formatter);
        }

        public ProtobufConverter(JsonParser parser, JsonFormatter formatter)
        {
            _parser = parser;
            _formatter = formatter;
        }

        public override bool CanConvert(Type objectType)
            => typeof(IMessage).IsAssignableFrom(objectType);

        public override object ReadJson(JsonReader reader,
            Type objectType, object existingValue,
            JsonSerializer serializer)
        {
            try
            {
                var converter = new ExpandoObjectConverter();
                var @object = (ExpandoObject)converter.ReadJson(reader,
                    objectType, existingValue, serializer);

                var message = (IMessage)Activator.CreateInstance(objectType);
                var descriptor = message.Descriptor;
                var fields = descriptor.Fields.InFieldNumberOrder();
                var output = new ExpandoObject();
                foreach (var pair in @object)
                {
                    var keyed = fields.Any(x => x.Name == pair.Key);
                    var dict = (IDictionary<string, object>)output;
                    if (keyed) dict.Add(pair.Key, pair.Value);
                }
                var json = JsonConvert.SerializeObject(output);
                return _parser.Parse(json, descriptor);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public override void WriteJson(JsonWriter writer,
            object value, JsonSerializer serializer)
        {
            try
            {
                var stringBuilder = new System.Text.StringBuilder();
                var stringWriter = new StringWriter(stringBuilder);
                _formatter.WriteValue(stringWriter, value);
                var json = stringBuilder.ToString();
                writer.WriteRawValue(json);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}