﻿using AutoMapper;
using Google.Protobuf.Reflection;
using MassTransit;
using MassTransit.Saga;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using System;
using System.Reflection;

namespace Common
{
    public static class DependencyInjectionExtensions
    {
        public static void ConfigureSerialization(
            this IBusFactoryConfigurator configurator,
            params MessageDescriptor[] descriptors)
        {
            var converter = ProtobufConverter.Create(descriptors: descriptors);
            configurator.ConfigureJsonSerializer(settings =>
            {
                settings.Converters.Add(converter);
                return settings;
            });
            configurator.ConfigureJsonDeserializer(settings =>
            {
                settings.Converters.Add(converter);
                return settings;
            });
        }

        public static IServiceCollection ConfigureApp<TSaga>(
            this IServiceCollection serviceCollection,
            IAsyncPolicy asyncPolicy,
            Action<ISagaConfigurator<TSaga>> saga,
            Func<Profile> profile) where TSaga : class, ISaga =>
            serviceCollection.AddSingleton(asyncPolicy)
                .AddMassTransit(config => config
                    .AddSaga(saga)
                    .InMemoryRepository()
                )
                .AddAutoMapper(config =>
                {
                    config.AddProfile(profile());
                }, assemblies: Array.Empty<Assembly>());
    }
}