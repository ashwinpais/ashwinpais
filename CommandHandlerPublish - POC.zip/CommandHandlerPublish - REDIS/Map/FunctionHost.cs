using MassTransit.WebJobs.ServiceBusIntegration;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using System.Threading;
using System.Threading.Tasks;

namespace MapService
{
    public class FunctionHost
    {
        private readonly IMessageReceiver _receiver;

        public FunctionHost(IMessageReceiver receiver)
        {
            _receiver = receiver;
        }

        [FunctionName("mapserviceconsumer")]
        public Task AssetServiceConsumer([ServiceBusTrigger("mapserviceconsumer")]
        Message message, CancellationToken cancellationToken)
        {
            return _receiver.HandleConsumer<MapConsumer>("mapserviceconsumer", message, cancellationToken);
        }
    }
}
