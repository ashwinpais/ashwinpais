﻿using Asset.Events.Serialization;
using EventStore.Abstractions;
using MassTransit;
using System.Threading.Tasks;

namespace MapService
{
    public class MapConsumer : IConsumer<GetAssetSummary>
    {
        private readonly IEventStore _eventStore;

        public MapConsumer(IEventStore eventStore)
        {
            _eventStore = eventStore;
        }

        Task IConsumer<GetAssetSummary>.Consume(ConsumeContext<GetAssetSummary> context)
        {
            var message = context.Message;

            var assets = _eventStore.GetStates(message.UserId).ConfigureAwait(false).GetAwaiter().GetResult(); ;

            context.Publish(new ResponseMessage()
            {
                UserId = context.Message.UserId,
                ConnectionId = context.Message.ConnectionId,
                MessageText = assets
            });

            return Task.CompletedTask;
        }
    }
}
