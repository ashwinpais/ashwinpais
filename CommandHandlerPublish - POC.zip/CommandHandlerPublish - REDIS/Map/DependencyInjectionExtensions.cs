﻿using Asset.Events.Serialization;
using Common;
using MassTransit;
using System;

namespace MapService
{
    static public class DependencyInjectionExtensions
    {
        public static void ConfigureHost<T>(this T configurator, IServiceProvider provider)
            where T : IBusFactoryConfigurator, IReceiveConfigurator<IReceiveEndpointConfigurator>
        {
            configurator.AutoStart = true;

            _ = provider;

            configurator.Message<ResponseMessage>(configTopology =>
            {
                configTopology.SetEntityName("signalr-topic");
            });

            configurator.ConfigureSerialization(GetAssetSummary.Descriptor,
                                                ResponseMessage.Descriptor);
        }
    }
}
