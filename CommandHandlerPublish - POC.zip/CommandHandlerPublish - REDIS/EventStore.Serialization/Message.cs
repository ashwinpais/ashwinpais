﻿using MassTransit;
using System;

namespace EventStore.Store.Serialization
{
    [Serializable]
    public partial class EventWriteRequest : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class EventWriteResponse : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class EventReadRequest : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class EventReadResponse : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class EventDetails : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }
}
