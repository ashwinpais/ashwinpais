﻿using Microsoft.Azure.Cosmos;

namespace EventStore.App.CosmosDB
{
    public partial class CosmosDBEventStore
    {
        private readonly CosmosClient _client;
        private readonly string _databaseId;
    }
}
