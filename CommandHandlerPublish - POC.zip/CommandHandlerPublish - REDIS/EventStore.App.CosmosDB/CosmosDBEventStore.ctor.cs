﻿using Microsoft.Azure.Cosmos;

namespace EventStore.App.CosmosDB
{
    public partial class CosmosDBEventStore
    {
        public CosmosDBEventStore(string endpointUrl,
                                  string authorizationKey,
                                  string databaseId)
        {
            _client = new CosmosClient(endpointUrl, authorizationKey);
            _databaseId = databaseId;
        }
    }
}
