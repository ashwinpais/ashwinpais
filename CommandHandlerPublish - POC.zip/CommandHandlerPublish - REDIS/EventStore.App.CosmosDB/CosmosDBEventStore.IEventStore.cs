﻿using Asset.Domain.Aggregates;
using EventStore.Abstractions;
using EventStore.Store.Serialization;
using Google.Protobuf.WellKnownTypes;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EventStore.App.CosmosDB
{
    public partial class CosmosDBEventStore : IEventStore
    {
        public async Task<List<EventDetails>> Get(string aggregateType, string userId)
        {
            Container container = _client.GetContainer(_databaseId, aggregateType);

            var sqlQueryText = "SELECT * FROM " + aggregateType + " e"
                + " WHERE e.userId  = @userId"
                + " ORDER BY e.aggregateId, e.eventTime";

            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText)
                .WithParameter("@userId", userId);

            DateTimeOffset eventTime = DateTimeOffset.MinValue;
            var events = new List<EventDetails>();

            FeedIterator<EventWrapper> feedIterator = container.GetItemQueryIterator<EventWrapper>(queryDefinition);
            while (feedIterator.HasMoreResults)
            {
                FeedResponse<EventWrapper> response = await feedIterator.ReadNextAsync();
                foreach (var eventWrapper in response)
                {
                    events.Add(new EventDetails()
                    {
                        EventTime = eventWrapper.EventTime.ToTimestamp(),
                        EventData = eventWrapper.EventData,
                        AggregateId = eventWrapper.AggregateId
                    });
                }
            }

            return events;
        }

        public async Task<IEventStream> Get(string aggregateId, string aggregateType, DateTimeOffset fromEventTime)
        {
            Container container = _client.GetContainer(_databaseId, aggregateType);

            var sqlQueryText = "SELECT * FROM " + aggregateType + " e"
                + " WHERE e.aggregateId = @aggregateId AND e.eventTime > @fromEventTime"
                + " ORDER BY e.eventTime";

            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText)
                .WithParameter("@aggregateId", aggregateId)
                .WithParameter("@fromEventTime", fromEventTime);

            DateTimeOffset eventTime = DateTimeOffset.MinValue;
            var events = new List<IEvent>();

            FeedIterator<EventWrapper> feedIterator = container.GetItemQueryIterator<EventWrapper>(queryDefinition);
            while (feedIterator.HasMoreResults)
            {
                FeedResponse<EventWrapper> response = await feedIterator.ReadNextAsync();
                foreach (var eventWrapper in response)
                {
                    eventTime = eventWrapper.EventTime;
                    var eventData = eventWrapper.EventData;

                    events.Add((IEvent)JsonConvert.DeserializeObject<IEvent>(eventData, new JsonSerializerSettings()
                    {
                        TypeNameHandling = TypeNameHandling.All
                    }));
                }
            }

            return new EventStream(aggregateId, eventTime, events);
        }

        public async Task<IEventStream> Get(string aggregateId, string aggregateType, string userId)
        {
            Container container = _client.GetContainer(_databaseId, aggregateType);

            var sqlQueryText = "SELECT * FROM " + aggregateType + " e"
                + " WHERE e.aggregateId = @aggregateId and e.userId = @userId"
                + " ORDER BY e.eventTime";

            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText)
                .WithParameter("@aggregateId", aggregateId)
                .WithParameter("@userId", userId);

            DateTimeOffset eventTime = DateTimeOffset.MinValue;
            var events = new List<IEvent>();

            FeedIterator<EventWrapper> feedIterator = container.GetItemQueryIterator<EventWrapper>(queryDefinition);
            while (feedIterator.HasMoreResults)
            {
                FeedResponse<EventWrapper> response = await feedIterator.ReadNextAsync();
                foreach (var eventWrapper in response)
                {
                    eventTime = eventWrapper.EventTime;
                    var eventData = eventWrapper.EventData;

                    events.Add((IEvent)JsonConvert.DeserializeObject<IEvent>(eventData, new JsonSerializerSettings()
                    {
                        TypeNameHandling = TypeNameHandling.All
                    }));
                }
            }

            return new EventStream(aggregateId, eventTime, events);
        }

        public async Task<IEventStream> Get(string aggregateId, string aggregateType, string userId, DateTimeOffset fromEventTime)
        {
            Container container = _client.GetContainer(_databaseId, aggregateType);

            var sqlQueryText = "SELECT * FROM " + aggregateType + " e"
                + " WHERE e.aggregateId = @aggregateId and e.userId = @userId"
                + " AND e.eventTime > @fromEventTime"
                + " ORDER BY e.eventTime";

            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText)
                .WithParameter("@aggregateId", aggregateId)
                .WithParameter("@userId", userId)
                .WithParameter("@fromEventTime", fromEventTime);

            DateTimeOffset eventTime = DateTimeOffset.MinValue;
            var events = new List<IEvent>();

            FeedIterator<EventWrapper> feedIterator = container.GetItemQueryIterator<EventWrapper>(queryDefinition);
            while (feedIterator.HasMoreResults)
            {
                FeedResponse<EventWrapper> response = await feedIterator.ReadNextAsync();
                foreach (var eventWrapper in response)
                {
                    eventTime = eventWrapper.EventTime;
                    var eventData = eventWrapper.EventData;

                    events.Add((IEvent)JsonConvert.DeserializeObject<IEvent>(eventData, new JsonSerializerSettings()
                    {
                        TypeNameHandling = TypeNameHandling.All
                    }));
                }
            }

            return new EventStream(aggregateId, eventTime, events);
        }

        public async Task<bool> Save(string aggregateId, string aggregateType,
                                     string userId, string eventName, string eventData)
        {
            Container container = _client.GetContainer(_databaseId, aggregateType);

            PartitionKey partitionKey = new PartitionKey(aggregateId);

            var serializeEvent = new EventWrapper
            {
                EventId = Guid.NewGuid(),
                AggregateId = aggregateId,
                EventName = eventName,
                EventTime = DateTimeOffset.Now,
                UserId = userId,
                EventData = eventData
            };

            await container.UpsertItemAsync(serializeEvent, partitionKey);

            return true;
        }

        public async Task<bool> SaveState(string aggregateId, string userId, IState state, DateTimeOffset eventTime, bool isDelete)
        {
            Container container = _client.GetContainer(_databaseId, "assetcache");

            PartitionKey partitionKey = new PartitionKey(aggregateId);

            if (isDelete)
            {
                try
                {
                    await container.DeleteItemAsync<StateWrapper>(aggregateId, partitionKey);
                }
                catch { }
            }
            else
            {
                var serializeState = new StateWrapper
                {
                    StateId = aggregateId,
                    EventTime = eventTime,
                    UserId = userId,
                    StateData = JsonConvert.SerializeObject(state, new JsonSerializerSettings()
                    {
                        TypeNameHandling = TypeNameHandling.All
                    })
                };

                await container.UpsertItemAsync(serializeState, partitionKey);
            }

            return true;
        }

        public Task<string> GetStates(string userId)
        {
            Container container = _client.GetContainer(_databaseId, "assetcache");

            var sqlQueryText = "SELECT * FROM assetcache e where e.userId = @userId"
                + " ORDER BY e.eventTime";

            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText)
                .WithParameter("@userId", userId);

            FeedIterator<StateWrapper> feedIterator = container.GetItemQueryIterator<StateWrapper>(queryDefinition);

            List<AssetState> assetStates = new List<AssetState>();

            while (feedIterator.HasMoreResults)
            {
                FeedResponse<StateWrapper> response = feedIterator.ReadNextAsync().Result;
                foreach (var eventWrapper in response)
                {
                    var stateData = eventWrapper.StateData;

                    var assetState = (JsonConvert.DeserializeObject<AssetState>(stateData, new JsonSerializerSettings()
                    {
                        TypeNameHandling = TypeNameHandling.All
                    }));

                    assetStates.Add(assetState);
                }
            }

            var assets = JsonConvert.SerializeObject(assetStates);

            return Task.FromResult(assets);
        }

        public async Task<List<IEventStream>> GetEventStreams(string aggregateType)
        {
            Container container = _client.GetContainer(_databaseId, aggregateType);

            var sqlQueryText = "SELECT * FROM " + aggregateType + " e"
                + " ORDER BY e.aggregateId, e.eventTime";

            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);

            DateTimeOffset eventTime = DateTimeOffset.MinValue;
            var eventStreams = new List<IEventStream>();
            var events = new List<IEvent>();
            var prevAggregateID = string.Empty;

            FeedIterator<EventWrapper> feedIterator = container.GetItemQueryIterator<EventWrapper>(queryDefinition);
            while (feedIterator.HasMoreResults)
            {
                FeedResponse<EventWrapper> response = await feedIterator.ReadNextAsync();
                foreach (var eventWrapper in response)
                {
                    if (string.Compare(prevAggregateID, eventWrapper.AggregateId, true) != 0 &&
                       events.Count > 0)
                    {
                        eventStreams.Add(new EventStream(prevAggregateID, eventTime, events));
                        eventTime = DateTimeOffset.MinValue;
                        events = new List<IEvent>();
                    }

                    eventTime = eventWrapper.EventTime;
                    var eventData = eventWrapper.EventData;

                    events.Add((IEvent)JsonConvert.DeserializeObject<IEvent>(eventData, new JsonSerializerSettings()
                    {
                        TypeNameHandling = TypeNameHandling.All
                    }));

                    prevAggregateID = eventWrapper.AggregateId;
                }
            }

            if (events.Count > 0)
            {
                eventStreams.Add(new EventStream(prevAggregateID, eventTime, events));
            }

            return eventStreams;
        }
    }
}
