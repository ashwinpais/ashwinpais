using MassTransit.WebJobs.ServiceBusIntegration;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using System.Threading;
using System.Threading.Tasks;

namespace EventStoreService
{
    public class FunctionHost
    {
        private readonly IMessageReceiver _receiver;

        public FunctionHost(IMessageReceiver receiver)
        {
            _receiver = receiver;
        }

        [FunctionName("eventstoreconsumer")]
        public Task EventStoreConsumer([ServiceBusTrigger("eventstoreconsumer")]
        Message message, CancellationToken cancellationToken)
        {
            return _receiver.HandleConsumer<EventStoreConsumer>("eventstoreconsumer", message, cancellationToken);
        }
    }
}
