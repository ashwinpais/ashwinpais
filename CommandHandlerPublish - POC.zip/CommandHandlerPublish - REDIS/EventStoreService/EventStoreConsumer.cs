﻿using EventStore.Abstractions;
using EventStore.Store.Serialization;
using Google.Protobuf.WellKnownTypes;
using MassTransit;
using System;
using System.Threading.Tasks;

namespace EventStoreService
{
    public class EventStoreConsumer : IConsumer<EventReadRequest>,
                                       IConsumer<EventWriteRequest>
    {
        private readonly IEventStore _eventStore;

        public EventStoreConsumer(IEventStore eventStore)
        {
            _eventStore = eventStore;
        }

        Task IConsumer<EventReadRequest>.Consume(ConsumeContext<EventReadRequest> context)
        {
            var message = context.Message;

            var events = _eventStore.Get(message.AggregateType,
                                     message.UserId).ConfigureAwait(false).GetAwaiter().GetResult();

            var eventReadResponse = new EventReadResponse();
            eventReadResponse.UserId = message.UserId;
            eventReadResponse.ConnectionId = message.ConnectionId;
            eventReadResponse.ClassToInstantiate = message.ClassToInstantiate;

            foreach (var @event in events)
            {
                eventReadResponse.Events.Add(@event);
            }

            context.Publish(eventReadResponse);

            return Task.CompletedTask;
        }

        Task IConsumer<EventWriteRequest>.Consume(ConsumeContext<EventWriteRequest> context)
        {
            var message = context.Message;

            _ = _eventStore.Save(message.AggregateId,
                                 message.AggregateType,
                                 message.UserId,
                                 message.EventName,
                                 message.EventData).ConfigureAwait(false).GetAwaiter().GetResult();

            context.Publish(new EventWriteResponse()
            {
                EventTime = DateTimeOffset.UtcNow.ToTimestamp(),
                ConnectionId = message.ConnectionId,
                UserId = message.UserId,
                AggregateId = message.AggregateId,
                EventName = message.EventName,
                EventData = message.EventData
            });

            return Task.CompletedTask;
        }
    }
}
