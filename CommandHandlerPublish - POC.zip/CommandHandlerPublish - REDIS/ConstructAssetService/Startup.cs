using Microsoft.Azure.Functions.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(ConstructAssetService.Functions.Startup))]
namespace ConstructAssetService.Functions
{
    using Asset.Events.Serialization;
    using Common;
    using MassTransit;
    using MassTransit.Azure.ServiceBus.Core;
    using Microsoft.Azure.Functions.Extensions.DependencyInjection;
    using Microsoft.Azure.ServiceBus;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    public class Startup : FunctionsStartup
    {
        public IConfiguration Configuration { get; }

        public Startup() =>
            Configuration = new ConfigurationBuilder()
                .AddEnvironmentVariables()
                .Build();

        public override void Configure(IFunctionsHostBuilder functionsHostBuilder)
        {
            IServiceCollection services = functionsHostBuilder.Services;

            var connection = Configuration.GetSection("AzureWebJobsServiceBus").Value.ToString();

            var loggerFactory = (ILoggerFactory)new LoggerFactory();

            var azureServiceBus = Bus.Factory.CreateUsingAzureServiceBus(busFactoryConfig =>
            {
                var host = busFactoryConfig.Host(connection, hostConfig =>
                {
                    hostConfig.TransportType = TransportType.AmqpWebSockets;
                });

                busFactoryConfig.Message<ConstructAsset>(configTopology =>
                {
                    configTopology.SetEntityName("commandtopic");
                });

                busFactoryConfig.Message<AssignAsset>(configTopology =>
                {
                    configTopology.SetEntityName("commandtopic");
                });

                busFactoryConfig.Message<DestructAsset>(configTopology =>
                {
                    configTopology.SetEntityName("commandtopic");
                });

                busFactoryConfig.ConfigureSerialization(ConstructAsset.Descriptor,
                                          AssignAsset.Descriptor,
                                          DestructAsset.Descriptor);
            });

            services.AddMassTransit(config =>
            {
                config.AddBus(busconfig => azureServiceBus);

            });

            services.AddSingleton<ILoggerFactory>(loggerFactory);
            services.AddScoped<FunctionHost>();
        }
    }
}
