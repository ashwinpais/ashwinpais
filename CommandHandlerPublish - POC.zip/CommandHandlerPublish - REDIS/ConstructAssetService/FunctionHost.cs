using Asset.Events.Serialization;
using MassTransit;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.SignalRService;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace ConstructAssetService.Functions
{
    public class FunctionHost : ServerlessHub
    {
        private readonly ILoggerFactory _loggerFactory;
        private readonly IPublishEndpoint _publishEndpoint;

        public FunctionHost(ILoggerFactory loggerFactory, IPublishEndpoint publishEndpoint)
        {
            _loggerFactory = loggerFactory;
            _publishEndpoint = publishEndpoint;
        }

        [FunctionName(nameof(AssetConstructor))]
        public async Task AssetConstructor([SignalRTrigger] InvocationContext invocationContext, string message)
        {
            var createAssetEvent = JsonConvert.DeserializeObject<ConstructAsset>(message);
            createAssetEvent.ConnectionId = invocationContext.ConnectionId;
            await _publishEndpoint.Publish<ConstructAsset>(createAssetEvent);
        }

        [FunctionName(nameof(AssetAssigner))]
        public async Task AssetAssigner([SignalRTrigger] InvocationContext invocationContext, string message)
        {
            var editAssetEvent = JsonConvert.DeserializeObject<AssignAsset>(message);
            editAssetEvent.ConnectionId = invocationContext.ConnectionId;
            await _publishEndpoint.Publish<AssignAsset>(editAssetEvent);
        }

        [FunctionName(nameof(AssetDestructor))]
        public async Task AssetDestructor([SignalRTrigger] InvocationContext invocationContext, string message)
        {
            var deleteAssetEvent = JsonConvert.DeserializeObject<DestructAsset>(message);
            deleteAssetEvent.ConnectionId = invocationContext.ConnectionId;
            await _publishEndpoint.Publish<DestructAsset>(deleteAssetEvent);
        }
    }
}
