﻿using Asset.Events.Serialization;
using Common;
using EventStore.Store.Serialization;
using MassTransit;
using System;

namespace HydrationService
{
    static public class DependencyInjectionExtensions
    {
        public static void ConfigureHost<T>(this T configurator, IServiceProvider provider)
            where T : IBusFactoryConfigurator, IReceiveConfigurator<IReceiveEndpointConfigurator>
        {
            configurator.AutoStart = true;

            _ = provider;

            configurator.Message<EventReadRequest>(configTopology =>
            {
                configTopology.SetEntityName("eventtopic");
            });

            configurator.Message<ReplayEventRequest>(configTopology =>
            {
                configTopology.SetEntityName("replaytopic");
            });

            configurator.Message<ResponseMessage>(configTopology =>
            {
                configTopology.SetEntityName("signalr-topic");
            });


            configurator.ConfigureSerialization(HydrateRequest.Descriptor,
                                                EventReadRequest.Descriptor,
                                                EventReadResponse.Descriptor,
                                                ReplayEventRequest.Descriptor,
                                                ReplayEventResponse.Descriptor,
                                                ResponseMessage.Descriptor);
        }
    }
}
