using MassTransit.WebJobs.ServiceBusIntegration;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using System.Threading;
using System.Threading.Tasks;

namespace HydrationService
{
    public class FunctionHost
    {
        private readonly IMessageReceiver _receiver;

        public FunctionHost(IMessageReceiver receiver)
        {
            _receiver = receiver;
        }

        [FunctionName("hydrationconsumer")]
        public Task HydrationConsumer([ServiceBusTrigger("hydrationconsumer")]
        Message message, CancellationToken cancellationToken)
        {
            return _receiver.HandleConsumer<HydrationConsumer>("hydrationconsumer", message, cancellationToken);
        }
    }
}
