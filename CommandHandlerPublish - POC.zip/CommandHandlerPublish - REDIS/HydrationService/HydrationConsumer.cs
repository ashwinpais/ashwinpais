﻿using Asset.Domain.Aggregates;
using Asset.Events.Serialization;
using EventStore.Abstractions;
using EventStore.Store.Serialization;
using MassTransit;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HydrationService
{
    public class HydrationConsumer : IConsumer<HydrateRequest>,
                                     IConsumer<EventReadResponse>,
                                     IConsumer<ReplayEventResponse>
    {
        private readonly IEventStore _eventStore;

        public HydrationConsumer(IEventStore eventStore)
        {
            _eventStore = eventStore;
        }

        Task IConsumer<HydrateRequest>.Consume(ConsumeContext<HydrateRequest> context)
        {
            try
            {
                var message = context.Message;

                context.Publish(new EventReadRequest()
                {
                    UserId = message.UserId,
                    ConnectionId = message.ConnectionId,
                    AggregateType = message.AggregateType,
                    ClassToInstantiate = message.ClassToInstantiate
                });
            }
            catch (Exception ex)
            {
                context.Publish(new EventReadRequest()
                {
                    UserId = ex.Message + ex.StackTrace
                });
            }


            return Task.CompletedTask;
        }

        Task IConsumer<EventReadResponse>.Consume(ConsumeContext<EventReadResponse> context)
        {
            var message = context.Message;

            var replayEventRequest = new ReplayEventRequest()
            {
                UserId = message.UserId,
                ConnectionId = message.ConnectionId,
                ClassToInstantiate = message.ClassToInstantiate
            };

            foreach (var @event in message.Events)
            {
                replayEventRequest.Events.Add(new Asset.Events.Serialization.EventDetails()
                {
                    EventData = @event.EventData,
                    EventTime = @event.EventTime,
                    AggregateId = @event.AggregateId
                });
            }
            context.Publish(replayEventRequest);

            return Task.CompletedTask;
        }

        Task IConsumer<ReplayEventResponse>.Consume(ConsumeContext<ReplayEventResponse> context)
        {
            var message = context.Message;

            try
            {
                List<EntityModel<IState>> entityModels = new List<EntityModel<IState>>();
                List<IState> states = new List<IState>();

                foreach (var asset in message.EntityModels)
                {
                    var obj = JsonConvert.DeserializeObject<EntityModel<IState>>(
                        asset, new JsonSerializerSettings()
                        {
                            TypeNameHandling = TypeNameHandling.All
                        });

                    entityModels.Add(obj);
                    states.Add(obj.entityState);
                }

                foreach (var entityModel in entityModels)
                {
                    _ = _eventStore.SaveState(entityModel.AggregateId,
                                              message.UserId,
                                              entityModel.entityState,
                                              entityModel.EventTime,
                                              !entityModel.entityState.IsActive).ConfigureAwait(false).
                                              GetAwaiter().GetResult();
                }

                var messageText = JsonConvert.SerializeObject(states);

                context.Publish(new ResponseMessage()
                {
                    UserId = context.Message.UserId,
                    ConnectionId = context.Message.ConnectionId,
                    MessageText = messageText
                });
            }
            catch (Exception ex)
            {
                context.Publish(new ResponseMessage()
                {
                    UserId = ex.StackTrace,
                    ConnectionId = ex.Message,
                    MessageText = JsonConvert.SerializeObject(context.Message)
                });
            }
            return Task.CompletedTask;
        }
    }
}
