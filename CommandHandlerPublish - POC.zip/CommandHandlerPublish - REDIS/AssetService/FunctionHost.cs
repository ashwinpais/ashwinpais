using MassTransit.WebJobs.ServiceBusIntegration;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using System.Threading;
using System.Threading.Tasks;

namespace EventStoreService
{
    public class FunctionHost
    {
        private readonly IMessageReceiver _receiver;

        public FunctionHost(IMessageReceiver receiver)
        {
            _receiver = receiver;
        }

        [FunctionName("assetserviceconsumer")]
        public Task AssetServiceConsumer([ServiceBusTrigger("assetserviceconsumer")]
        Message message, CancellationToken cancellationToken)
        {
            return _receiver.HandleConsumer<AssetServiceConsumer>("assetserviceconsumer", message, cancellationToken);
        }
    }
}
