﻿using Asset.Events.Serialization;
using Common;
using EventStore.Store.Serialization;
using MassTransit;
using System;

namespace EventStoreService
{
    static public class DependencyInjectionExtensions
    {
        public static void ConfigureHost<T>(this T configurator, IServiceProvider provider)
            where T : IBusFactoryConfigurator, IReceiveConfigurator<IReceiveEndpointConfigurator>
        {
            configurator.AutoStart = true;

            _ = provider;

            configurator.Message<EventWriteRequest>(configTopology =>
            {
                configTopology.SetEntityName("eventtopic");
            });

            configurator.Message<GetAssetSummary>(configTopology =>
            {
                configTopology.SetEntityName("maptopic");
            });

            configurator.ConfigureSerialization(EventWriteRequest.Descriptor,
                                                EventWriteResponse.Descriptor,
                                                ConstructAsset.Descriptor,
                                                AssignAsset.Descriptor,
                                                DestructAsset.Descriptor,
                                                GetAssetSummary.Descriptor);
        }
    }
}
