﻿using Asset.Domain.Aggregates;
using Asset.Events.Serialization;
using EventStore.Abstractions;
using EventStore.Store.Serialization;
using Google.Protobuf.WellKnownTypes;
using MassTransit;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace EventStoreService
{
    public class AssetServiceConsumer : IConsumer<ConstructAsset>,
                                      IConsumer<AssignAsset>,
                                      IConsumer<DestructAsset>,
                                      IConsumer<EventWriteResponse>
    {
        private readonly IEventStore _eventStore;

        public AssetServiceConsumer(IEventStore eventStore)
        {
            _eventStore = eventStore;
        }

        Task IConsumer<ConstructAsset>.Consume(ConsumeContext<ConstructAsset> context)
        {
            var message = context.Message;

            AssetConstructed assetConstructed = new AssetConstructed()
            {
                AssetId = context.Message.AssetId,
                AssetName = context.Message.AssetName,
                UserId = context.Message.UserId,
                ConnectionId = context.Message.ConnectionId,
                PresentValue = context.Message.PresentValue,
                Description = context.Message.Description
            };

            context.Publish(new EventWriteRequest()
            {
                AggregateId = $"asset:{message.AssetId}",
                AggregateType = "assetevents",
                UserId = message.UserId,
                EventName = nameof(AssetConstructed),
                EventTime = DateTimeOffset.UtcNow.ToTimestamp(),
                ConnectionId = message.ConnectionId,
                EventData = JsonConvert.SerializeObject(assetConstructed, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                })
            });

            return Task.CompletedTask;
        }

        Task IConsumer<AssignAsset>.Consume(ConsumeContext<AssignAsset> context)
        {
            var message = context.Message;

            AssetAssigned assetAssigned = new AssetAssigned()
            {
                AssetId = context.Message.AssetId,
                AssetName = context.Message.AssetName,
                UserId = context.Message.UserId,
                ConnectionId = context.Message.ConnectionId,
                PresentValue = context.Message.PresentValue,
                Description = context.Message.Description
            };

            context.Publish(new EventWriteRequest()
            {
                AggregateId = $"asset:{message.AssetId}",
                AggregateType = "assetevents",
                UserId = message.UserId,
                ConnectionId = message.ConnectionId,
                EventName = nameof(AssetAssigned),
                EventTime = DateTimeOffset.UtcNow.ToTimestamp(),
                EventData = JsonConvert.SerializeObject(assetAssigned, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                })
            });

            return Task.CompletedTask;
        }

        Task IConsumer<DestructAsset>.Consume(ConsumeContext<DestructAsset> context)
        {
            var message = context.Message;

            AssetDestructed assetDestructed = new AssetDestructed()
            {
                AssetId = context.Message.AssetId,
                AssetName = context.Message.AssetName,
                UserId = context.Message.UserId,
                ConnectionId = context.Message.ConnectionId,
                PresentValue = context.Message.PresentValue,
                Description = context.Message.Description
            };

            context.Publish(new EventWriteRequest()
            {
                AggregateId = $"asset:{message.AssetId}",
                AggregateType = "assetevents",
                UserId = message.UserId,
                ConnectionId = message.ConnectionId,
                EventName = nameof(AssetDestructed),
                EventTime = DateTimeOffset.UtcNow.ToTimestamp(),
                EventData = JsonConvert.SerializeObject(assetDestructed, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                })
            });

            return Task.CompletedTask;
        }

        Task IConsumer<EventWriteResponse>.Consume(ConsumeContext<EventWriteResponse> context)
        {
            var message = context.Message;

            var assetModel = new EntityModel<AssetState>();
            assetModel.entityState = new AssetState();

            if (string.Compare(message.EventName, nameof(AssetConstructed), true) == 0)
            {
                var assetConstructed = JsonConvert.DeserializeObject<AssetConstructed>(message.EventData, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                });

                assetModel.entityState.AssetId = assetConstructed.AssetId;
                assetModel.entityState.AssetName = assetConstructed.AssetName;
                assetModel.entityState.PresentValue = assetConstructed.PresentValue;
                assetModel.entityState.Description = assetConstructed.Description;
                assetModel.entityState.IsActive = true;
            }
            else if (string.Compare(message.EventName, nameof(AssetAssigned), true) == 0)
            {
                var assetAssigned = JsonConvert.DeserializeObject<AssetAssigned>(message.EventData, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                });

                assetModel.entityState.AssetId = assetAssigned.AssetId;
                assetModel.entityState.AssetName = assetAssigned.AssetName;
                assetModel.entityState.PresentValue = assetAssigned.PresentValue;
                assetModel.entityState.Description = assetAssigned.Description;
                assetModel.entityState.IsActive = true;
            }
            else if (string.Compare(message.EventName, nameof(AssetDestructed), true) == 0)
            {
                var assetDestructed = JsonConvert.DeserializeObject<AssetDestructed>(message.EventData, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                });

                assetModel.entityState.AssetId = assetDestructed.AssetId;
                assetModel.entityState.AssetName = assetDestructed.AssetName;
                assetModel.entityState.PresentValue = assetDestructed.PresentValue;
                assetModel.entityState.Description = assetDestructed.Description;
                assetModel.entityState.IsActive = false;
            }

            _ = _eventStore.SaveState(message.AggregateId,
                                      message.UserId,
                                      assetModel.entityState,
                                      assetModel.EventTime,
                                      !assetModel.entityState.IsActive).
                                      ConfigureAwait(false).GetAwaiter().GetResult();

            context.Publish(new GetAssetSummary()
            {
                ConnectionId = message.ConnectionId,
                UserId = message.UserId,
                EventName = message.EventName,
                EventData = JsonConvert.SerializeObject(assetModel.entityState, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                })
            });

            return Task.CompletedTask;
        }
    }
}
