﻿using EventStore.Abstractions;
using Google.Protobuf;
using MassTransit;
using System;

namespace Asset.Events.Serialization
{
    [Serializable]
    public partial class ConstructAsset : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class AssignAsset : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class DestructAsset : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class AssetConstructed : IEvent, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class AssetAssigned : IEvent, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class AssetDestructed : IEvent, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class GetAssets : IMessage, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class GetAssetSummary : IMessage, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class ResponseMessage : IMessage, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class HydrateRequest : IMessage, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class ReplayEventRequest : IMessage, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class ReplayEventResponse : IMessage, CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }

    [Serializable]
    public partial class EventDetails : CorrelatedBy<Guid>
    {
        public Guid CorrelationId => new Guid();
    }
}
