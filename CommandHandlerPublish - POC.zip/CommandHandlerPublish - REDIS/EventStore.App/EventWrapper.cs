﻿using Newtonsoft.Json;
using System;

namespace EventStore.App
{
    public class EventWrapper
    {
        [JsonProperty("id")]
        public Guid EventId { get; set; }

        [JsonProperty("aggregateId")]
        public string AggregateId { get; set; }

        [JsonProperty("userId")]
        public string UserId { get; set; }

        [JsonProperty("eventName")]
        public string EventName { get; set; }

        [JsonProperty("eventTime")]
        public DateTimeOffset EventTime { get; set; }

        [JsonProperty("eventData")]
        public string EventData { get; set; }
    }
}