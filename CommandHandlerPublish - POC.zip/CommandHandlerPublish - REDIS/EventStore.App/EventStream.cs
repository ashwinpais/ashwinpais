﻿using EventStore.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EventStore.App
{
    public class EventStream : IEventStream
    {
        private readonly string _id;

        private readonly List<IEvent> _events;

        private readonly DateTimeOffset _eventTime;

        public EventStream(string id, DateTimeOffset eventTime, IEnumerable<IEvent> events)
        {
            _id = id;
            _eventTime = eventTime;
            _events = events.ToList();
        }

        string IEventStream.AggregateId => _id;

        DateTimeOffset IEventStream.EventTime => _eventTime;

        IEnumerable<IEvent> IEventStream.Events => _events;
    }
}