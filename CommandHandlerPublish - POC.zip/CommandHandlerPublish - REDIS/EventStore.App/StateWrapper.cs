﻿using Newtonsoft.Json;
using System;

namespace EventStore.App
{
    public class StateWrapper
    {
        [JsonProperty("id")]
        public string StateId { get; set; }

        [JsonProperty("eventTime")]
        public DateTimeOffset EventTime { get; set; }

        [JsonProperty("userId")]
        public string UserId { get; set; }

        [JsonProperty("stateData")]
        public string StateData { get; set; }
    }
}