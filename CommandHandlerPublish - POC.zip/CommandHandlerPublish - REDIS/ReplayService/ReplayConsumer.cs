﻿using Asset.Domain.Aggregates;
using Asset.Events.Serialization;
using EventStore.Abstractions;
using EventStore.App;
using MassTransit;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HydrationService
{
    public class ReplayConsumer : IConsumer<ReplayEventRequest>
    {
        Task IConsumer<ReplayEventRequest>.Consume(ConsumeContext<ReplayEventRequest> context)
        {
            var message = context.Message;

            var eventStreams = GetEventStreams(message);

            var replayResponse = new ReplayEventResponse()
            {
                UserId = message.UserId,
                ConnectionId = message.ConnectionId
            };

            foreach (var eventStream in eventStreams)
            {
                var objectToInstantiate = message.ClassToInstantiate;
                var objectType = Type.GetType(objectToInstantiate);
                var instantiateObject = Activator.CreateInstance(objectType);

                var entityModel = new EntityModel<IState>();
                entityModel.AggregateId = eventStream.AggregateId;
                entityModel.EventTime = eventStream.EventTime;

                entityModel.entityState = (IState)instantiateObject;
                entityModel.Apply(eventStream.Events, eventStream.EventTime);

                replayResponse.EntityModels.Add(JsonConvert.SerializeObject(entityModel, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                }));
            }

            context.Publish(replayResponse);

            return Task.CompletedTask;
        }

        public List<IEventStream> GetEventStreams(ReplayEventRequest replayEventRequest)
        {
            var eventDetails = replayEventRequest.Events;

            var eventStreams = new List<IEventStream>();
            var events = new List<IEvent>();
            var aggregateId = string.Empty;
            DateTimeOffset eventTime = DateTimeOffset.MinValue;

            foreach (var @event in eventDetails)
            {
                if (string.Compare(aggregateId, @event.AggregateId, true) != 0 &&
                    events.Count > 0)
                {
                    eventStreams.Add(new EventStream(aggregateId, eventTime, events));
                    eventTime = DateTimeOffset.MinValue;
                    events = new List<IEvent>();
                }

                eventTime = @event.EventTime.ToDateTime();
                var eventData = @event.EventData;

                events.Add((IEvent)JsonConvert.DeserializeObject<IEvent>(eventData, new JsonSerializerSettings()
                {
                    TypeNameHandling = TypeNameHandling.All
                }));

                aggregateId = @event.AggregateId;
            }

            if (events.Count > 0)
            {
                eventStreams.Add(new EventStream(aggregateId, eventTime, events));
            }

            return eventStreams;
        }
    }
}
