using MassTransit.WebJobs.ServiceBusIntegration;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using System.Threading;
using System.Threading.Tasks;

namespace HydrationService
{
    public class FunctionHost
    {
        private readonly IMessageReceiver _receiver;

        public FunctionHost(IMessageReceiver receiver)
        {
            _receiver = receiver;
        }

        [FunctionName("replayconsumer")]
        public Task ReplayConsumer([ServiceBusTrigger("replayconsumer")]
        Message message, CancellationToken cancellationToken)
        {
            return _receiver.HandleConsumer<ReplayConsumer>("replayconsumer", message, cancellationToken);
        }
    }
}
